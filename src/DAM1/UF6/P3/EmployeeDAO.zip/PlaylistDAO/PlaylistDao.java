package UF6.P3.PlaylistDAO;

import UF6.P3.EmployeeDAO.Employee;

import java.sql.SQLException;
import java.util.List;

public interface PlaylistDao {
    public int create(Playlist playlist) throws SQLException;
    public Playlist read(int idPlaylist) throws SQLException;
    public void update(Playlist playlist) throws SQLException;
    public void delete(int idPlaylist) throws SQLException;
    public List<Playlist> getPlaylist() throws SQLException;
}
