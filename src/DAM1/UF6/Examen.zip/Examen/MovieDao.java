package UF6.Examen;

import java.sql.SQLException;
import java.util.ArrayList;

public interface MovieDao {
    public Movie read (int movieId) throws SQLException;
}
